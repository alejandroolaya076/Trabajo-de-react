import { useState } from "react";
import '../css/registro.css';

export default function RegistrationForm() {
  const [formData, setFormData] = useState({
    documentType: "",
    documentNumber: "",
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    city: "",
    address: "",
    occupation: "",
    services: "",
  })

  const [errors, setErrors] = useState({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const documentTypes = [
    { value: "", label: "Seleccione tipo de documento" },
    { value: "cedula", label: "Cédula de Ciudadanía" },
    { value: "tarjeta", label: "Tarjeta de Identidad" },
    { value: "pasaporte", label: "Pasaporte" },
    { value: "extranjeria", label: "Cédula de Extranjería" },
  ]

  const validateForm = () => {
    const newErrors = {}

    if (!formData.documentType) {
      newErrors.documentType = "Seleccione un tipo de documento"
    }

    if (!formData.documentNumber) {
      newErrors.documentNumber = "El número de documento es requerido"
    }

    if (!formData.firstName.trim()) {
      newErrors.firstName = "Los nombres son requeridos"
    }

    if (!formData.lastName.trim()) {
      newErrors.lastName = "Los apellidos son requeridos"
    }

    if (!formData.phone) {
      newErrors.phone = "El teléfono es requerido"
    }

    if (!formData.email) {
      newErrors.email = "El correo electrónico es requerido"
    }

    if (!formData.city.trim()) {
      newErrors.city = "La ciudad es requerida"
    }

    if (!formData.address.trim()) {
      newErrors.address = "La dirección es requerida"
    }

    if (!formData.occupation.trim()) {
      newErrors.occupation = "La ocupación es requerida"
    }

    if (!formData.services.trim()) {
      newErrors.services = "Describa los servicios en los que le gustaría participar"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))

    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }))
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))
      console.log("Form submitted:", formData)
      setIsSubmitted(true)
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const resetForm = () => {
    setIsSubmitted(false)
    setFormData({
      documentType: "",
      documentNumber: "",
      firstName: "",
      lastName: "",
      phone: "",
      email: "",
      city: "",
      address: "",
      occupation: "",
      services: "",
    })
  }

  if (isSubmitted) {
    return (
      <div className="form-container">
        <div className="success-message">
          <div className="success-icon">✓</div>
          <h2>¡Registro Exitoso!</h2>
          <p>Su información ha sido registrada correctamente.</p>
          <button className="btn btn-primary" onClick={resetForm}>
            Iniciar sesion
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="form-container">
      <form className="registration-form" onSubmit={handleSubmit}>
        <h1 className="form-title">Formulario de Registro</h1>

        <div className="form-grid">
          <div className="form-group">
            <label htmlFor="documentType" className="form-label">
              Tipo de documento *
            </label>
            <select
              id="documentType"
              name="documentType"
              value={formData.documentType}
              onChange={handleInputChange}
              className={`form-select ${errors.documentType ? "error" : ""}`}
            >
              {documentTypes.map((type) => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
            {errors.documentType && <span className="error-message">{errors.documentType}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="documentNumber" className="form-label">
              Número de documento *
            </label>
            <input
              type="text"
              id="documentNumber"
              name="documentNumber"
              value={formData.documentNumber}
              onChange={handleInputChange}
              className={`form-input ${errors.documentNumber ? "error" : ""}`}
              placeholder="Ingrese su número de documento"
            />
            {errors.documentNumber && <span className="error-message">{errors.documentNumber}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="firstName" className="form-label">
              Nombres *
            </label>
            <input
              type="text"
              id="firstName"
              name="firstName"
              value={formData.firstName}
              onChange={handleInputChange}
              className={`form-input ${errors.firstName ? "error" : ""}`}
              placeholder="Ingrese sus nombres"
            />
            {errors.firstName && <span className="error-message">{errors.firstName}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="lastName" className="form-label">
              Apellidos *
            </label>
            <input
              type="text"
              id="lastName"
              name="lastName"
              value={formData.lastName}
              onChange={handleInputChange}
              className={`form-input ${errors.lastName ? "error" : ""}`}
              placeholder="Ingrese sus apellidos"
            />
            {errors.lastName && <span className="error-message">{errors.lastName}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="phone" className="form-label">
              Teléfono *
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleInputChange}
              className={`form-input ${errors.phone ? "error" : ""}`}
              placeholder="Ingrese su número de teléfono"
            />
            {errors.phone && <span className="error-message">{errors.phone}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="email" className="form-label">
              Correo electrónico *
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              className={`form-input ${errors.email ? "error" : ""}`}
              placeholder="Ingrese su correo electrónico"
            />
            {errors.email && <span className="error-message">{errors.email}</span>}
          </div>
          <div className="form-group">
            <label htmlFor="city" className="form-label">
              Ciudad *
            </label>
            <input
              type="text"
              id="city"
              name="city"
              value={formData.city}
              onChange={handleInputChange}
              className={`form-input ${errors.city ? "error" : ""}`}
              placeholder="Ingrese su ciudad"
            />
            {errors.city && <span className="error-message">{errors.city}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="address" className="form-label">
              Dirección *
            </label>
            <input
              type="text"
              id="address"
              name="address"
              value={formData.address}
              onChange={handleInputChange}
              className={`form-input ${errors.address ? "error" : ""}`}
              placeholder="Ingrese su dirección"
            />
            {errors.address && <span className="error-message">{errors.address}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="occupation" className="form-label">
              Ocupación *
            </label>
            <input
              type="text"
              id="occupation"
              name="occupation"
              value={formData.occupation}
              onChange={handleInputChange}
              className={`form-input ${errors.occupation ? "error" : ""}`}
              placeholder="Ingrese su ocupación"
            />
            {errors.occupation && <span className="error-message">{errors.occupation}</span>}
          </div>
        </div>

        <div className="form-group services-group">
          <label htmlFor="services" className="form-label">
            Servicios en los que le gustaría participar *
          </label>
          <textarea
            id="services"
            name="services"
            value={formData.services}
            onChange={handleInputChange}
            className={`form-textarea ${errors.services ? "error" : ""}`}
            placeholder=""
            rows="6"
            cols="50"
          />
          {errors.services && <span className="error-message">{errors.services}</span>}
        </div>

        <button
          type="submit"
          className={`btn btn-primary btn-submit ${isSubmitting ? "loading" : ""}`}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <>
              <span className="spinner"></span>
              Registrando...
            </>
          ) : (
            "Registrar Candidato"
          )}
        </button>
      </form>
    </div>
  )
}