import React, { useState } from 'react';
import '../css/ingreso.css';
import { useNavigate } from 'react-router-dom';

const Ingreso = () => {
  const [tipoDocumento, setTipoDocumento] = useState('');
  const [numeroDocumento, setNumeroDocumento] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    // Aquí iría la lógica de autenticación
    if (tipoDocumento && numeroDocumento) {
      navigate('/home'); // Redirige al home si es válido
    } else {
      alert('Por favor, complete todos los campos.');
    }
  };

  return (
    <div className="login-container">
      <form id="formulario" onSubmit={handleSubmit}>
        <h2>Iniciar Sesión</h2>

        <label htmlFor="tipoDocumento">Tipo de Documento:</label>
        <select
          id="tipoDocumento"
          value={tipoDocumento}
          onChange={(e) => setTipoDocumento(e.target.value)}
          required
        >
          <option value="">Selecciona un tipo</option>
          <option value="cc">Cédula de Ciudadanía</option>
          <option value="ti">Tarjeta de Identidad</option>
        </select>

        <label htmlFor="numeroDocumento">Número de Documento:</label>
        <input
          id="numeroDocumento"
          type="text"
          value={numeroDocumento}
          onChange={(e) => setNumeroDocumento(e.target.value)}
          required
        />

        <button type="submit">Ingresar</button>

        <div className="register-link">
          ¿No tienes cuenta? <a href="/registro">Regístrate</a>
        </div>
      </form>
    </div>

  );
};

export default Ingreso;
