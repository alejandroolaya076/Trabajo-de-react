import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const ubicaciones = [
  {
    nombre: 'Manzana Suba',
    lat: 4.7485,
    lng: -74.1011,
  },
  {
    nombre: 'Manzana Bosa',
    lat: 4.6126,
    lng: -74.1863,
  },
  {
    nombre: 'Manzana Soacha',
    lat: 4.5870,
    lng: -74.2170,
  }
];


function Mapa() {
  return (
    <div style={{ height: '500px', width: '100%', margin: '2rem 0' }}>
      <MapContainer center={[4.65, -74.1]} zoom={11} scrollWheelZoom={false} style={{ height: '100%', width: '100%' }}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {ubicaciones.map((punto, index) => (
          <Marker key={index} position={[punto.lat, punto.lng]}>
            <Popup>
              <strong>{punto.nombre}</strong><br />
              {punto.descripcion}
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}

export default Mapa;
