import { useState } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import "../css/ServiceForm.css";

// Corrige los íconos predeterminados de Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const ServiceForm = () => {
  const categorias = {
    salud: [
      {
        nombre: "Atención Médica General",
        descripcion: "Consultas básicas de salud para mujeres y sus familias",
      },
      {
        nombre: "Terapias Corporales (masajes, relajación)",
        descripcion:
          "Sesiones breves de masaje o terapias para el alivio físico y estrés",
      },
    ],
    educacion: [
      {
        nombre: "Formación en Finanzas Personales",
        descripcion:
          "Educación financiera básica para el manejo del hogar y ahorro",
      },
      {
        nombre: "Clases de Defensa Personal",
        descripcion:
          "Entrenamiento básico para seguridad personal y empoderamiento físico",
      },
    ],
    psicosocial: [
      {
        nombre: "Acompañamiento Psicosocial",
        descripcion:
          "Espacios de escucha activa, redes de apoyo y salud emocional",
      },
      {
        nombre: "Talleres de Autocuidado",
        descripcion:
          "Charlas y actividades para el bienestar físico, mental y emocional de las mujeres cuidadoras",
      },
    ],
    juridico: [
      {
        nombre: "Orientación Jurídica",
        descripcion:
          "Asesoría legal gratuita sobre derechos de las mujeres, procesos de familia y violencia de género",
      },
    ],
    cuidado: [
      {
        nombre: "Cuidado Temporal de Personas Dependientes",
        descripcion:
          "Apoyo comunitario para relevar a las cuidadoras por algunas horas",
      },
    ],
    emprendimiento: [
      {
        nombre: "Capacitación en Emprendimiento",
        descripcion:
          "Talleres para fortalecer ideas de negocio y autoempleo femenino",
      },
    ],
    apoyos: [
      {
        nombre: "Asesoría para Acceso a Subsidios",
        descripcion:
          "Guía sobre programas de ayudas económicas y subsidios gubernamentales",
      },
    ],
  };

  const coordenadasLocalidades = {
    Bosa: [4.6225, -74.1865],
    Usme: [4.4646, -74.1136],
    Soacha: [4.5794, -74.2168],
  };

  const [localidad, setLocalidad] = useState("");
  const [categoriaSeleccionada, setCategoriaSeleccionada] = useState("");
  const [servicioSeleccionado, setServicioSeleccionado] = useState("");

  const serviciosDisponibles = categoriaSeleccionada
    ? categorias[categoriaSeleccionada]
    : [];

  const handleSubmit = (e) => {
    e.preventDefault();
    const servicio = serviciosDisponibles.find(
      (s) => s.nombre === servicioSeleccionado
    );

    console.log("Formulario enviado:");
    console.log("Localidad:", localidad);
    console.log("Categoría:", categoriaSeleccionada);
    console.log("Servicio:", servicio?.nombre);
    console.log("Descripción:", servicio?.descripcion);
  };

  return (
    <div className="app-container">
      <div className="main-content">
        <h1 className="main-title">Reservar Servicios</h1>
        <div className="form-container">
          <form onSubmit={handleSubmit} className="service-form">

            {/* Localidad */}
            <div className="form-group">
              <label>Localidad</label>
              <select
                value={localidad}
                onChange={(e) => setLocalidad(e.target.value)}
                className="form-select"
                required
              >
                <option value="">-- Selecciona una localidad --</option>
                <option value="Bosa">Bosa</option>
                <option value="Usme">Usme</option>
                <option value="Soacha">Soacha</option>
              </select>
            </div>

            {/* Categoría */}
            <div className="form-group">
              <label>Categoría</label>
              <select
                value={categoriaSeleccionada}
                onChange={(e) => {
                  setCategoriaSeleccionada(e.target.value);
                  setServicioSeleccionado("");
                }}
                className="form-select"
                required
              >
                <option value="">-- Selecciona una categoría --</option>
                {Object.keys(categorias).map((cat) => (
                  <option key={cat} value={cat}>
                    {cat.charAt(0).toUpperCase() + cat.slice(1)}
                  </option>
                ))}
              </select>
            </div>

            {/* Servicio */}
            {categoriaSeleccionada && (
              <div className="form-group">
                <label>Nombre del Servicio</label>
                <select
                  value={servicioSeleccionado}
                  onChange={(e) => setServicioSeleccionado(e.target.value)}
                  className="form-select"
                  required
                >
                  <option value="">-- Selecciona un servicio --</option>
                  {serviciosDisponibles.map((s, index) => (
                    <option key={index} value={s.nombre}>
                      {s.nombre}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Descripción automática */}
            {servicioSeleccionado && (
              <div className="form-group">
                <div className="auto-description">
                  <strong>Descripción:</strong>
                  <br />
                  {
                    serviciosDisponibles.find(
                      (s) => s.nombre === servicioSeleccionado
                    )?.descripcion
                  }
                </div>
              </div>
            )}

            <button type="submit" className="submit-button">
              Reservar
            </button>
          </form>

          {/* Mapa dinámico */}
          {localidad && coordenadasLocalidades[localidad] && (
            <div style={{ height: "300px", marginTop: "20px" }}>
              <MapContainer
                center={coordenadasLocalidades[localidad]}
                zoom={13}
                scrollWheelZoom={false}
                style={{ height: "100%", width: "100%", borderRadius: "10px" }}
              >
                <TileLayer
                  attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a>'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                <Marker position={coordenadasLocalidades[localidad]}>
                  <Popup>Localidad: {localidad}</Popup>
                </Marker>
              </MapContainer>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ServiceForm;
