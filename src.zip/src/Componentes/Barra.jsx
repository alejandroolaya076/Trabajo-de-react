import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../css/barra.css';

function Barra() {
  const [menuAbierto, setMenuAbierto] = useState(false);

  const alternarMenu = () => {
    setMenuAbierto(!menuAbierto);
  };

  return (
    <nav className="barra">
      <div className="barra-logo"> Manzanas del Cuidado</div>
    </nav>
  );
}

export default Barra;
