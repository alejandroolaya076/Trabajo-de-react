import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../css/tarjeta.css';

function Tarjeta({ id, titulo, descripcion, imagen }) {
  const navigate = useNavigate();

  const irADetalle = () => {
    navigate(`/servicio/${id}`);
  };

  return (
    <div className="tarjeta" onClick={irADetalle} style={{ cursor: 'pointer' }}>
      <img src={imagen} alt={titulo} className="tarjeta-img" />
      <div className="tarjeta-body">
        <h3>{titulo}</h3>
        <p>{descripcion}</p>
      </div>
    </div>
  );
}

export default Tarjeta;
