import React, { useEffect, useState } from 'react';
import '../css/AdminPanel.css';

function AdminPanel() {
  const [usuarios, setUsuarios] = useState([]);
  const [servicios, setServicios] = useState([]);
  const [nuevoServicio, setNuevoServicio] = useState({ nombre: '', descripcion: '' });

  useEffect(() => {
    cargarUsuarios();
    cargarServicios();
  }, []);

  const cargarUsuarios = () => {
    fetch('http://localhost:3001/usuarios')
      .then(res => res.json())
      .then(data => setUsuarios(data))
      .catch(err => console.error('Error al cargar usuarios:', err));
  };

  const cargarServicios = () => {
    fetch('http://localhost:3001/servicios')
      .then(res => res.json())
      .then(data => setServicios(data))
      .catch(err => console.error('Error al cargar servicios:', err));
  };

  const handleAgregarServicio = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('http://localhost:3001/servicios', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(nuevoServicio)
      });
      if (res.ok) {
        setNuevoServicio({ nombre: '', descripcion: '' });
        cargarServicios();
      }
    } catch (error) {
      console.error('Error al agregar servicio:', error);
    }
  };

  const handleEliminarServicio = async (id) => {
    try {
      const res = await fetch(`http://localhost:3001/servicios/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) cargarServicios();
    } catch (error) {
      console.error('Error al eliminar servicio:', error);
    }
  };

  return (
    <div className="admin-panel">
      <h2>Panel de Administración</h2>

      <section>
        <h3>Usuarios Registrados</h3>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Apellido</th>
              <th>Correo</th>
              <th>Ciudad</th>
            </tr>
          </thead>
          <tbody>
            {usuarios.map(usuario => (
              <tr key={usuario.id_user}>
                <td>{usuario.id_user}</td>
                <td>{usuario.nombre}</td>
                <td>{usuario.apellido}</td>
                <td>{usuario.correo}</td>
                <td>{usuario.ciudad}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section>
        <h3>Servicios Disponibles</h3>
        <form onSubmit={handleAgregarServicio} className="form-agregar-servicio">
          <input
            type="text"
            placeholder="Nombre del servicio"
            value={nuevoServicio.nombre}
            onChange={e => setNuevoServicio({ ...nuevoServicio, nombre: e.target.value })}
            required
          />
          <input
            type="text"
            placeholder="Descripción"
            value={nuevoServicio.descripcion}
            onChange={e => setNuevoServicio({ ...nuevoServicio, descripcion: e.target.value })}
            required
          />
          <button type="submit">Agregar Servicio</button>
        </form>

        <ul className="lista-servicios">
          {servicios.map(servicio => (
            <li key={servicio.id_servicio}>
              <strong>{servicio.nombre}:</strong> {servicio.descripcion}
              <button onClick={() => handleEliminarServicio(servicio.id_servicio)}>Eliminar</button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

export default AdminPanel;