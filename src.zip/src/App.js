import { BrowserRouter, Routes, Route } from 'react-router-dom';

import Ingreso from './Pages/Ingreso';
import Registro from './Pages/Registro';
import Barra from './Componentes/Barra';
import ServiceForm from './Pages/ServiceForm';


function App() {
  return (
    <BrowserRouter>
      <Barra />
      <Routes>
        <Route path="/" element={<Ingreso />} />
        <Route path="/registro" element={<Registro />} />
        <Route path="/servicio" element={<ServiceForm />} />
      </Routes>
    </BrowserRouter>
  );
}


export default App;
